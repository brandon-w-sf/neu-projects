public abstract class Tile {

  public abstract void display(); 
  public abstract boolean isPassable(); 
}